This game was created as a project for Schulich Ignite Flare session. 

Objective: Survive as long as possible while defending from enemies (bison and ducks)

Move with WASD, shoot bullets with space bar, and place mines using left shift.
(Mines only available after reaching level 7)

Player: 
	health - 100
	bullet damage - 10
	bullet cooldown - 1 second
	mine damage - 30
	mine cooldown - 5 seconds

Bison:
	health - 20
	hit damage - 20
	kill points - 3
	move speed - slow
Duck:
	health - 1
	hit damage - 1
	kill points - 1
	move speed - fast

After each level, enemy spawn speeds will increase. 